		

<?php $__env->startSection('title','cara kirim naskah'); ?>

<?php $__env->startSection('content'); ?>

<div class="stricky-header stricked-menu main-menu">
    <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
</div>
<section class="page-header">
            <div class="page-header__bg" style="background-image: url(<?php echo e(asset('assets')); ?>/images/backgrounds/page-header.JPG);"></div>
            <!-- /.page-header__bg -->
            <div class="container">
                <h2>Cara Kirim Naskah</h2>
                <ul class="thm-breadcrumb list-unstyled">
                    <li><a href="index.html">Home</a></li>
                    <li>/</li>
                    <li><span>About</span></li>
                </ul><!-- /.thm-breadcrumb list-unstyled -->
            </div><!-- /.container -->
        </section><!-- /.page-header -->
        <section class="about-one">
            <div class="container">
                <div class="row">
                    <div class="card">
                        <div class="card-header text-center" style="font-weight: bold;">CARA KIRIM NASKAH
                         </div>
                      <div class="card-body">
                        <blockquote class="blockquote mb-0">
                          <p class="text-justify">Naskah yang akan dikirimkan ke Penerbit Manggu tentu harus mengikuti peraturan dan syarat kelengkapan naskah. Setelah kelengkapan naskah Anda sudah kumplit dan siap untuk dikirim, kirimkan naskah ke Redaksi Penerbit Manggu dengan metode pengiriman sebagai berikut:</p>
                          <p>
                                <ul style="font-weight: bold;">Pengiriman naskah dalam bentuk SOFTCOPY</ul>
                              <li>Untuk menghemat ukuran file, file naskah bisa dikompres menggunakan aplikasi pengompres file, seperti WinZip, WinRar, dll</li>
                              <LI>Nama file disesuaikan dengan isinya, misalnya: daftar isi, bab 1, bab 2, bab 3, daftar pustaka, dll.</LI>
                              <LI>Sertakan file README yang Anda isi dengan keterangan yang perlu diketahui penerbit, misalnya nama file-file yang disertakan, jumlah bab, jumlah halaman, dll.</LI>
                              <li>Sertakan juga file kelengkapan naskah di luar naskah, seperti foto KTP, Silabu/RPP/RPS, dll. Apa saja kelengkapan naskah? Bisa Anda lihat di sini.</li>
                              <li>Naskah dikirim langsung ke redaksi Penerbit Manggu melalui alamat email: manggumedia@gmail.com.</li>
                          </p>
                          <p>
                              <ul style="font-weight: bold;">Pengiriman naskah dalam bentuk HARDCOPY</ul>
                              <li>Naskah print out dijilid dengan rapi dan lengkap dari mulai: judul, Kata Pengantar, Daftar Isi, Bab 1, bab 2, bab…, Daftar Pustaka, Glosarium, Indeks, dan Biodata Penulis.</li>
                              <li>File naskah dikemas dalam bentuk CD/DVD.</li>
                              <li>Naskah print out yang sudah dijilid dan file naskah yang sudah dicopy ke dalam bentuk CD/DVD kemudian dikemas ke dalam amplop besar dan disertakan juga kelengkapan naskah berupa foto KTP, Silabus/RPP/RPS, pas foto, dan kelengkapan lainnya.</li>
                              <li>Naskah yang sudah siap, selanjutnya kirim langsung ke Redaksi Penerbit Manggu dengan alamat Komplek Taman Kopo Katapang Blok B1 No. 16 Katapang, Bandung, Jawa Barat 40921.</li>
                          </p>
                          <footer class="blockquote-footer">Penerbit Manggu<cite title="Source Title"> 2022</cite></footer>
                        </blockquote>
                      </div>
                    </div>

                </div>
            </div>
        </section>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penerbitmanggu\resources\views/layouts/cara-kirim-naskah.blade.php ENDPATH**/ ?>