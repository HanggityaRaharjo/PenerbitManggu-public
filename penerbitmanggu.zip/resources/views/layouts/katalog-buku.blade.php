@extends('layouts.master')      

@section('title','Katalog Buku')

@section('content')

<div class="stricky-header stricked-menu main-menu">
    <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
</div>
<section class="page-header">
            <div class="page-header__bg" style="background-image: url({{asset('assets')}}/images/backgrounds/page-header.JPG);"></div>
            <!-- /.page-header__bg -->
            <div class="container">
                <h2>Katalog Buku</h2>
                <ul class="thm-breadcrumb list-unstyled">
                    <li><a href="index.html">Home</a></li>
                    <li>/</li>
                    <li><span>About</span></li>
                </ul><!-- /.thm-breadcrumb list-unstyled -->
            </div><!-- /.container -->
        </section><!-- /.page-header -->

                <section class="products-page">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-3">
                        <div class="product-sidebar">
                            <div class="product-sidebar__single product-sidebar__search-widget">
                                <form action="#">
                                    <input type="text" placeholder="Search">
                                    <button class="organik-icon-magnifying-glass" type="submit"></button>
                                </form>
                            </div><!-- /.product-sidebar__single -->
                            <div class="product-sidebar__single">
                                <h3>Price</h3>
                                <div class="product-sidebar__price-range">
                                    <div class="range-slider-price" id="range-slider-price"></div>
                                    <div class="form-group">
                                        <div class="left">
                                            <p>$<span id="min-value-rangeslider"></span></p>
                                            <span>-</span>
                                            <p>$<span id="max-value-rangeslider"></span></p>
                                        </div><!-- /.left -->
                                        <div class="right">
                                            <input type="submit" class="thm-btn" value="Filter">
                                        </div><!-- /.right -->
                                    </div>
                                </div><!-- /.product-sidebar__price-range -->
                            </div><!-- /.product-sidebar__single -->
                            <div class="product-sidebar__single">
                                <h3>Categories</h3>
                                <ul class="list-unstyled product-sidebar__links">
                                    <li><a href="#">Vegetables <i class="fa fa-angle-right"></i></a></li>
                                    <li><a href="#">Fresh Fruits <i class="fa fa-angle-right"></i></a></li>
                                    <li><a href="#">Dairy Products <i class="fa fa-angle-right"></i></a></li>
                                    <li><a href="#">Tomatos <i class="fa fa-angle-right"></i></a></li>
                                    <li><a href="#">Oranges <i class="fa fa-angle-right"></i></a></li>
                                </ul><!-- /.list-unstyled product-sidebar__links -->
                            </div><!-- /.product-sidebar__single -->
                        </div><!-- /.product-sidebar -->
                    </div><!-- /.col-sm-12 col-md-12 col-lg-3 -->
                    <div class="col-sm-12 col-md-12 col-lg-9">
                        <div class="product-sorter">
                            <p>Showing 1–9 of 12 results</p>
                            <div class="product-sorter__select">
                                <select class="selectpicker">
                                    <option value="#">Sort by popular</option>
                                    <option value="#">Sort by popular</option>
                                    <option value="#">Sort by popular</option>
                                    <option value="#">Sort by popular</option>
                                </select>
                            </div><!-- /.product-sorter__select -->
                        </div><!-- /.product-sorter -->
                        <div class="row">
                            <div class="col-md-6 col-lg-4">
                                <div class="product-card">
                                    <div class="product-card__image">
                                        <img src="assets/images/products/product-1-1.jpg" alt="">
                                        <div class="product-card__image-content">
                                            <a href="#"><i class="organik-icon-heart"></i></a>
                                            <a href="cart.html"><i class="organik-icon-shopping-cart"></i></a>
                                        </div><!-- /.product-card__image-content -->
                                    </div><!-- /.product-card__image -->
                                    <div class="product-card__content">
                                        <div class="product-card__left">
                                            <h3><a href="product-details.html">Banana</a></h3>
                                            <p>$1.00</p>
                                        </div><!-- /.product-card__left -->
                                        <div class="product-card__right">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div><!-- /.product-card__right -->
                                    </div><!-- /.product-card__content -->
                                </div><!-- /.product-card -->
                            </div><!-- /.col-md-6 col-lg-4 -->
                            <div class="col-md-6 col-lg-4">
                                <div class="product-card">
                                    <div class="product-card__image">
                                        <img src="assets/images/products/product-1-2.jpg" alt="">
                                        <div class="product-card__image-content">
                                            <a href="#"><i class="organik-icon-heart"></i></a>
                                            <a href="cart.html"><i class="organik-icon-shopping-cart"></i></a>
                                        </div><!-- /.product-card__image-content -->
                                    </div><!-- /.product-card__image -->
                                    <div class="product-card__content">
                                        <div class="product-card__left">
                                            <h3><a href="product-details.html">Tomatoes</a></h3>
                                            <p>$3.00</p>
                                        </div><!-- /.product-card__left -->
                                        <div class="product-card__right">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div><!-- /.product-card__right -->
                                    </div><!-- /.product-card__content -->
                                </div><!-- /.product-card -->
                            </div><!-- /.col-md-6 col-lg-4 -->
                            <div class="col-md-6 col-lg-4">
                                <div class="product-card">
                                    <div class="product-card__image">
                                        <img src="assets/images/products/product-1-3.jpg" alt="">
                                        <div class="product-card__image-content">
                                            <a href="#"><i class="organik-icon-heart"></i></a>
                                            <a href="cart.html"><i class="organik-icon-shopping-cart"></i></a>
                                        </div><!-- /.product-card__image-content -->
                                    </div><!-- /.product-card__image -->
                                    <div class="product-card__content">
                                        <div class="product-card__left">
                                            <h3><a href="product-details.html">Bread</a></h3>
                                            <p>$2.00</p>
                                        </div><!-- /.product-card__left -->
                                        <div class="product-card__right">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div><!-- /.product-card__right -->
                                    </div><!-- /.product-card__content -->
                                </div><!-- /.product-card -->
                            </div><!-- /.col-md-6 col-lg-4 -->
                            <div class="col-md-6 col-lg-4">
                                <div class="product-card">
                                    <div class="product-card__image">
                                        <img src="assets/images/products/product-1-4.jpg" alt="">
                                        <div class="product-card__image-content">
                                            <a href="#"><i class="organik-icon-heart"></i></a>
                                            <a href="cart.html"><i class="organik-icon-shopping-cart"></i></a>
                                        </div><!-- /.product-card__image-content -->
                                    </div><!-- /.product-card__image -->
                                    <div class="product-card__content">
                                        <div class="product-card__left">
                                            <h3><a href="product-details.html">Apples</a></h3>
                                            <p>$5.00</p>
                                        </div><!-- /.product-card__left -->
                                        <div class="product-card__right">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div><!-- /.product-card__right -->
                                    </div><!-- /.product-card__content -->
                                </div><!-- /.product-card -->
                            </div><!-- /.col-md-6 col-lg-4 -->
                            <div class="col-md-6 col-lg-4">
                                <div class="product-card">
                                    <div class="product-card__image">
                                        <img src="assets/images/products/product-1-5.jpg" alt="">
                                        <div class="product-card__image-content">
                                            <a href="#"><i class="organik-icon-heart"></i></a>
                                            <a href="cart.html"><i class="organik-icon-shopping-cart"></i></a>
                                        </div><!-- /.product-card__image-content -->
                                    </div><!-- /.product-card__image -->
                                    <div class="product-card__content">
                                        <div class="product-card__left">
                                            <h3><a href="product-details.html">Olive Oil</a></h3>
                                            <p>$6.00</p>
                                        </div><!-- /.product-card__left -->
                                        <div class="product-card__right">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div><!-- /.product-card__right -->
                                    </div><!-- /.product-card__content -->
                                </div><!-- /.product-card -->
                            </div><!-- /.col-md-6 col-lg-4 -->
                            <div class="col-md-6 col-lg-4">
                                <div class="product-card">
                                    <div class="product-card__image">
                                        <img src="assets/images/products/product-1-6.jpg" alt="">
                                        <div class="product-card__image-content">
                                            <a href="#"><i class="organik-icon-heart"></i></a>
                                            <a href="cart.html"><i class="organik-icon-shopping-cart"></i></a>
                                        </div><!-- /.product-card__image-content -->
                                    </div><!-- /.product-card__image -->
                                    <div class="product-card__content">
                                        <div class="product-card__left">
                                            <h3><a href="product-details.html">Eggs</a></h3>
                                            <p>$4.00</p>
                                        </div><!-- /.product-card__left -->
                                        <div class="product-card__right">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div><!-- /.product-card__right -->
                                    </div><!-- /.product-card__content -->
                                </div><!-- /.product-card -->
                            </div><!-- /.col-md-6 col-lg-4 -->
                            <div class="col-md-6 col-lg-4">
                                <div class="product-card">
                                    <div class="product-card__image">
                                        <img src="assets/images/products/product-1-7.jpg" alt="">
                                        <div class="product-card__image-content">
                                            <a href="#"><i class="organik-icon-heart"></i></a>
                                            <a href="cart.html"><i class="organik-icon-shopping-cart"></i></a>
                                        </div><!-- /.product-card__image-content -->
                                    </div><!-- /.product-card__image -->
                                    <div class="product-card__content">
                                        <div class="product-card__left">
                                            <h3><a href="product-details.html">Honey</a></h3>
                                            <p>$9.00</p>
                                        </div><!-- /.product-card__left -->
                                        <div class="product-card__right">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div><!-- /.product-card__right -->
                                    </div><!-- /.product-card__content -->
                                </div><!-- /.product-card -->
                            </div><!-- /.col-md-6 col-lg-4 -->
                            <div class="col-md-6 col-lg-4">
                                <div class="product-card">
                                    <div class="product-card__image">
                                        <img src="assets/images/products/product-1-8.jpg" alt="">
                                        <div class="product-card__image-content">
                                            <a href="#"><i class="organik-icon-heart"></i></a>
                                            <a href="cart.html"><i class="organik-icon-shopping-cart"></i></a>
                                        </div><!-- /.product-card__image-content -->
                                    </div><!-- /.product-card__image -->
                                    <div class="product-card__content">
                                        <div class="product-card__left">
                                            <h3><a href="product-details.html">Onions</a></h3>
                                            <p>$2.00</p>
                                        </div><!-- /.product-card__left -->
                                        <div class="product-card__right">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div><!-- /.product-card__right -->
                                    </div><!-- /.product-card__content -->
                                </div><!-- /.product-card -->
                            </div><!-- /.col-md-6 col-lg-4 -->
                            <div class="col-md-6 col-lg-4">
                                <div class="product-card">
                                    <div class="product-card__image">
                                        <img src="assets/images/products/product-1-9.jpg" alt="">
                                        <div class="product-card__image-content">
                                            <a href="#"><i class="organik-icon-heart"></i></a>
                                            <a href="cart.html"><i class="organik-icon-shopping-cart"></i></a>
                                        </div><!-- /.product-card__image-content -->
                                    </div><!-- /.product-card__image -->
                                    <div class="product-card__content">
                                        <div class="product-card__left">
                                            <h3><a href="product-details.html">Cabbage</a></h3>
                                            <p>$3.00</p>
                                        </div><!-- /.product-card__left -->
                                        <div class="product-card__right">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div><!-- /.product-card__right -->
                                    </div><!-- /.product-card__content -->
                                </div><!-- /.product-card -->
                            </div><!-- /.col-md-6 col-lg-4 -->
                        </div><!-- /.row -->
                        <div class="text-center">
                            <a href="#" class="thm-btn products__load-more">Load More</a><!-- /.thm-btn -->
                        </div><!-- /.text-center -->
                    </div><!-- /.col-sm-12 col-md-12 col-lg-9 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.products-page -->
@endsection