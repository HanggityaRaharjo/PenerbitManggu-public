      

<?php $__env->startSection('title','Manggu Info'); ?>

<?php $__env->startSection('content'); ?>

<div class="stricky-header stricked-menu main-menu">
    <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
</div>
<section class="page-header">
            <div class="page-header__bg" style="background-image: url(<?php echo e(url('assets')); ?>/images/backgrounds/page-header.JPG);"></div>
            <!-- /.page-header__bg -->
            <div class="container">
                <h2>Manggu Info</h2>
                <ul class="thm-breadcrumb list-unstyled">
                    <li><a href="index.html">Home</a></li>
                    <li>/</li>
                    <li><span>About</span></li>
                </ul><!-- /.thm-breadcrumb list-unstyled -->
            </div><!-- /.container -->
        </section><!-- /.page-header -->

        <div class="blog-page">
            <div class="container">
                <div class="row">
                    <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-12 col-md-6 col-lg-4">
                        <div class="blog-card" style="margin-bottom: -85px;">
                            <div class="blog-card__image" style="margin-bottom: 5px;">
                                <div class="blog-card__date"><?php echo e(Carbon\Carbon::parse($b->created_at)->locale('id')->translatedFormat('d M')); ?></div><!-- /.blog-card__date -->
                                <img src="<?php echo e(url($b->photo)); ?>" style="width: 370px; height: 280px;">
                                <a href="<?php echo e(route('manggu-info-halaman', $b->slug)); ?>"></a>
                            </div><!-- /.blog-card__image -->
<!--                             <div class="post-meta">
                                <h3 class="title">
                                </h3>
                                <p><?php echo Str::subStr($b->deskripsi, 0, 150); ?></p>
                                <a href="<?php echo e(route('manggu-info-halaman', $b->slug)); ?>" class="btn btn-primary"style="background-color: #a01f24; border-color: #615253;">Selengkapnya »</a>
                            </div> -->

                            <div class="blog-card__content">
                                <div class="blog-card__meta">
                                </div><!-- /.blog-card__meta -->
                                <h3 class="title"><a href="<?php echo e(route('manggu-info-halaman', $b->slug)); ?>"><?php echo Str::subStr($b->judul, 0, 50); ?>...</a></h3>
                                <p><?php echo Str::subStr($b->deskripsi, 0, 150); ?>...</p>
                                <a href="<?php echo e(route('manggu-info-halaman', $b->slug)); ?>" class="btn btn-primary" style="background-color: #a01f24; border-color: #615253;">Selengkapnya »</a>
                            </div><!-- /.blog-card__content -->
                        </div><!-- /.blog-card -->
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.blog-page -->
        <div style="margin: 20px;">
            <?php echo e($berita->links('vendor.pagination.custom')); ?>

        </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penerbitmanggu\resources\views/layouts/manggu-info.blade.php ENDPATH**/ ?>