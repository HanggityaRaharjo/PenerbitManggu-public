		

<?php $__env->startSection('title','Manajemen'); ?>

<?php $__env->startSection('content'); ?>

<div class="stricky-header stricked-menu main-menu">
    <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
</div>
<section class="page-header">
    <div class="page-header__bg" style="background-image: url(<?php echo e(asset('assets')); ?>/images/backgrounds/page-header.JPG);"></div>
            <!-- /.page-header__bg -->
        <div class="container">
            <h2>Manajemen</h2>
                <ul class="thm-breadcrumb list-unstyled">
                    <li><a href="index.html">Home</a></li>
                    <li>/</li>
                    <li><span>Manajemen</span></li>
                </ul><!-- /.thm-breadcrumb list-unstyled -->
        </div><!-- /.container -->
</section><!-- /.page-header -->
<section class="About-one">
    <div class="container">
        <div class="row">
            <img src="assets/images/shapes/about-leaf-1-1.png" alt="" class="about-one__shape-1">
        </div>        
    </div>
</section>
         <section>
            <img src="assets/images/shapes/team-shape-1.png" alt="" class="team-one__shape-1">
            <img src="assets/images/shapes/team-shape-2.png" alt="" class="team-one__shape-2">
            <div class="container">
                <div class="block-title text-center">
                    <div class="block-title__decor"></div><!-- /.block-title__decor -->
                    <p>Professional People</p>
                    <h3>Struktur Manajemen Perusahaan</h3>
                </div><!-- /.block-title -->
                <div class="row">
                    <div class="col-md-6 col-lg-3">
                        <div class="team-card">
                            <div class="team-card__image">
                                <img src="assets/images/team/team-1-1.png" alt="">
                            </div><!-- /.team-card__image -->
                            <div class="team-card__content">
                                <h3>Aep Syaiful Hamidin</h3>
                                <div class="team-card__social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-facebook-square"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div><!-- /.team-card__social -->
                            </div><!-- /.team-card__content -->
                        </div><!-- /.team-card -->
                    </div><!-- /.col-md-6 col-lg-3 -->
                    <div class="col-md-6 col-lg-3">
                        <div class="team-card">
                            <div class="team-card__image">
                                <img src="assets/images/team/team-1-2.png" alt="">
                            </div><!-- /.team-card__image -->
                            <div class="team-card__content">
                                <h3>Ora McLaughlin</h3>
                                <div class="team-card__social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-facebook-square"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div><!-- /.team-card__social -->
                            </div><!-- /.team-card__content -->
                        </div><!-- /.team-card -->
                    </div><!-- /.col-md-6 col-lg-3 -->
                    <div class="col-md-6 col-lg-3">
                        <div class="team-card">
                            <div class="team-card__image">
                                <img src="assets/images/team/team-1-3.png" alt="">
                            </div><!-- /.team-card__image -->
                            <div class="team-card__content">
                                <h3>Peter Ramsey</h3>
                                <div class="team-card__social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-facebook-square"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div><!-- /.team-card__social -->
                            </div><!-- /.team-card__content -->
                        </div><!-- /.team-card -->
                    </div><!-- /.col-md-6 col-lg-3 -->
                    <div class="col-md-6 col-lg-3">
                        <div class="team-card">
                            <div class="team-card__image">
                                <img src="assets/images/team/team-1-4.png" alt="">
                            </div><!-- /.team-card__image -->
                            <div class="team-card__content">
                                <h3>Eric Miller</h3>
                                <div class="team-card__social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-facebook-square"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div><!-- /.team-card__social -->
                            </div><!-- /.team-card__content -->
                        </div><!-- /.team-card -->
                    </div><!-- /.col-md-6 col-lg-3 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.team-one -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\manggu\resources\views/layouts/manajemen.blade.php ENDPATH**/ ?>