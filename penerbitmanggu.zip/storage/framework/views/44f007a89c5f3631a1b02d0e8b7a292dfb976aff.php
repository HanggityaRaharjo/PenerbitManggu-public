		

<?php $__env->startSection('title','Penulis'); ?>

<?php $__env->startSection('content'); ?>

<div class="stricky-header stricked-menu main-menu">
    <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
</div>
<section class="page-header">
            <div class="page-header__bg" style="background-image: url(<?php echo e(asset('assets')); ?>/images/backgrounds/page-header.JPG);"></div>
            <!-- /.page-header__bg -->
            <div class="container">
                <h2>Penulis</h2>
                <ul class="thm-breadcrumb list-unstyled">
                    <li><a href="index.html">Home</a></li>
                    <li>/</li>
                    <li><span>Penulis</span></li>
                </ul><!-- /.thm-breadcrumb list-unstyled -->
            </div><!-- /.container -->
        </section><!-- /.page-header -->
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="tabs-content">
                                <div class="tab active-tab" id="review">
                                    <div class="reviews-box">
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <div class="product_reviews_box">
                                                    <div class="product_reviews_single">
                                                        <div class="product_reviews_image">
                                                            <img src="assets/images/products/review-1.jpg" alt="">
                                                        </div>
                                                        <div class="product_reviews_content">
                                                            <h3>Kevin Martins<span>15 Nov, 2019</span></h3>
                                                            <p>Lorem ipsum is simply free text used by copytyping refreshing.
                                                                Neque porro est qui dolorem ipsum quia quaed inventore veritatis
                                                                et quasi architecto beatae vitae dicta sunt explicabo.</p>
                                                            <div class="product_reviews_rating product_detail_review">
                                                                <a href="#"><i class="fa fa-star"></i></a>
                                                                <a href="#"><i class="fa fa-star"></i></a>
                                                                <a href="#"><i class="fa fa-star"></i></a>
                                                                <a href="#"><i class="fa fa-star"></i></a>
                                                                <a href="#" class="deactive"><i class="fa fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="product_reviews_single">
                                                        <div class="product_reviews_image">
                                                            <img src="assets/images/products/review-2.jpg" alt="">
                                                        </div>
                                                        <div class="product_reviews_content">
                                                            <h3>Kevin Martins<span>15 Nov, 2019</span></h3>
                                                            <p>Lorem ipsum is simply free text used by copytyping refreshing.
                                                                Neque porro est qui dolorem ipsum quia quaed inventore veritatis
                                                                et quasi architecto beatae vitae dicta sunt explicabo.</p>
                                                            <div class="product_reviews_rating product_detail_review">
                                                                <a href="#"><i class="fa fa-star"></i></a>
                                                                <a href="#"><i class="fa fa-star"></i></a>
                                                                <a href="#"><i class="fa fa-star"></i></a>
                                                                <a href="#"><i class="fa fa-star"></i></a>
                                                                <a href="#" class="deactive"><i class="fa fa-star"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penerbitmanggu\resources\views/layouts/penulis.blade.php ENDPATH**/ ?>