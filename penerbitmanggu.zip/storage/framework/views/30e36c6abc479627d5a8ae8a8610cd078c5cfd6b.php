
<?php if($paginator->hasPages()): ?>
    <ul class="list-unstyled post-pagination d-flex justify-content-center">
        <?php if($paginator->onFirstPage()): ?>
            <li><a><i class="fa fa-angle-left"></i></a></li>
        <?php else: ?>
            <li><a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev"><i class="fa fa-angle-left"></i></a></li>
        <?php endif; ?>
      
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
            <?php if(is_string($element)): ?>
                <li class="disabled"><span><?php echo e($element); ?></span></li>
            <?php endif; ?>       
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <li class="active my-active"><a><?php echo e($page); ?></a></li>
                    <?php else: ?>
                        <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <?php if($paginator->hasMorePages()): ?>
            <li><a style="background-color: #a01f24" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"><i class="fa fa-angle-right"></i></a></li>
        <?php else: ?>
            <li><a style="background-color: #a01f24"><i class="fa fa-angle-right"></i></a></li>
        <?php endif; ?>
    </ul>
<?php endif; ?> 
<?php /**PATH C:\xampp\htdocs\manggu\resources\views/vendor/pagination/custom.blade.php ENDPATH**/ ?>