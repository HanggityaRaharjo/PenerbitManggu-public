    

<?php $__env->startSection('title','Data Royalti'); ?>


<?php $__env->startSection('content'); ?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Royalti</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <button type="button" class="btn btn-info">
                <i class="fa fa-upload" style="font-size:15px">Upload Data</i>
              </button>
              <button type="button" class="btn btn-info" data-toggle="modal" data-target="#tambah">
                <i class="fa fa-plus" style="font-size:15px">Tambah Data</i>
              </button>
            <div class="modal fade" id="tambah" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                     <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Tambah Berita</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(url('/data-royalti-admin/store')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="card-body" style="text-align: left;">
                                    <div class="form-group">
                                        <label>Judul Buku</label>
                                        <input class="form-control" name="judul" placeholder="Enter..." autocomplete="off">
                                    </div>
                                    <div class="form-group">
                                        <label>Penulis</label>
                                        <input class="form-control" name="penulis" placeholder="Enter..." autocomplete="off">
                                    </div>
                                    <div class="form-group">
                                        <label>Harga</label>
                                        <input class="form-control" name="harga" placeholder="Enter..." autocomplete="off">
                                    </div>
                                    <div class="form-group">
                                        <label>Terjual</label>
                                        <input class="form-control" name="terjual" placeholder="Enter..." autocomplete="off">
                                    </div>
                                </div>
                                <div class="modal-footer justify-content-between">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            </ol>
          </div>
        </div>
      </div>
    </section>
    <section class="content">
      <div class="card">
        <div class="card-body">
            <div class="table-responsive">
              <nav class="navbar navbar-light justify-content-between">
                <form class="form-inline">
                  <div class="form-group">
                    <input type="search" id="cari" class="form-control mx-sm-3" aria-describedby="passwordHelpInline">
                  </div>
                </form>
              </nav>
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Judul</th>
                            <th scope="col">Penulis</th>
                            <th scope="col">Harga</th>
                            <th scope="col">Terjual</th>
                            <th scope="col">Omzet</th>
                            <th scope="col">Royalti(15%)</th>
                            <th scope="col">Pph</th>
                            <th scope="col">Admin </th>
                            <th scope="col">NetRoyalti</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <?php $no=1; ?>
                    <?php $__currentLoopData = $dataroyalti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                            <th scope="row"><?php echo e($no++); ?></th>
                            <td><?php echo e($d->judul); ?></td>
                            <td><?php echo e($d->penulis); ?></td>
                            <td>Rp.<?php echo e($d->harga); ?></td>
                            <td><?php echo e($d->terjual); ?></td>
                            <td>Rp.<?php echo e($d->harga*$d->terjual); ?></td>
                            <td>Rp.<?php echo e(($d->harga*$d->terjual)*0.15); ?></td>
                            <td>Rp.6000</td>
                            <td>Rp.6000</td>
                            <td>Rp.<?php echo e(((($d->harga*$d->terjual)*0.15)-6000)-6000); ?></td>
                            <td>
                                <a class="btn btn-sm btn-info fas fa-edit" data-toggle="modal" data-target="#ubah<?php echo e($d->id); ?>"></a>
                                <div class="modal fade" id="ubah<?php echo e($d->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h4 class="modal-title">Ubah Data</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                          <span aria-hidden="true">&times;</span>
                                        </button>
                                      </div>
                                      <div class="modal-body">
                                      <form action="<?php echo e(url('/data-royalti-admin/update')); ?>/<?php echo e($d->id); ?>" method="POST" enctype="multipart/form-data">
                                          <?php echo csrf_field(); ?>
                                          <div class="card-body" style="text-align: left;">
                                              <div class="form-group">
                                                  <label>Judul</label>
                                                  <input class="form-control" name="judul" placeholder="Enter..." value="<?php echo e($d->judul); ?>">
                                              </div>
                                              <div class="form-group">
                                                  <label>Penulis</label>
                                                  <input class="form-control" name="Penulis" placeholder="Enter..." value="<?php echo e($d->penulis); ?>">
                                              </div>
                                              <div class="form-group">
                                                  <label>Harga</label>
                                                  <input class="form-control" name="harga" placeholder="Enter..." value="<?php echo e($d->harga); ?>">
                                              </div>
                                              <div class="form-group">
                                                  <label>Terjual</label>
                                                  <input class="form-control" name="terjual" placeholder="Enter..." value="<?php echo e($d->terjual); ?>">
                                              </div>
                                          </div>
                                      </div>
                                        <div class="modal-footer justify-content-between">
                                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                          <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                      </form>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <a class="btn btn-sm btn-danger fas fa-trash-alt" href="<?php echo e(url('/data-royalti-admin/delete')); ?>/<?php echo e($d->id); ?>" onclick="return confirm('yakin?');"></a>
                                <!-- <a class="btn btn-sm btn-danger fas fa-trash-alt" href="/exportpdf">Export</a> -->
                            </td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\manggu\resources\views/layouts/admin/data-royalti-admin.blade.php ENDPATH**/ ?>