    

<?php $__env->startSection('title','Berita'); ?>

<?php $__env->startSection('content'); ?>

 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Berita</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
           <button type="button" class="btn btn-info" data-toggle="modal" data-target="#tambah">
                <i class="fa fa-plus" style="font-size:15px">Tambah Berita</i>
            </button>
                <div class="modal fade" id="tambah" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                         <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title">Tambah Berita</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(url('/berita-admin/store')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="card-body" style="text-align: left;">
                                        <div class="form-group">
                                            <label>Photo(370x310)</label>
                                            <input type="file" class="form-control " name="photo" style="height: 45px;">
                                        </div>
                                        <div class="form-group">
                                            <label>Judul</label>
                                            <input class="form-control" name="judul" placeholder="Enter..." autocomplete="off">
                                        </div>
                                        <div class="form-group">
                                            <label>Deskripsi</label>
                                            <textarea class="form-control" name="deskripsi" id="editor" placeholder="Enter..."></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer justify-content-between">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0">
                    <thead>
                        <tr class="text-dark">
                            <th scope="col">No</th>
                            <th scope="col">Diunggah</th>
                            <th scope="col">Photo</th>
                            <th scope="col">Judul</th>
                            <th scope="col">Deskripsi</th>
                            <th scope="col">Status</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <?php echo e($errors); ?>

                    <?php $no=1; ?>
                     <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                            <th scope="row"><?php echo e($no++); ?></th>
                            <td><?php echo e(Carbon\Carbon::parse($b->created_at)->locale('id')->translatedFormat('d M')); ?></td>
                            <td>
                                <img src="<?php echo e(url($b->photo)); ?>" alt="Image" class="image" style="max-width: 100%">
                            </td>
                            <td><?php echo e($b->judul); ?></td>
                            <td><?php echo Str::subStr($b->deskripsi, 0, 270); ?></td>
                            <td>Draft</td>
                            <td>
                                <a class="btn btn-sm btn-info fas fa-eye" href=""></a>
                                <a type="button" class="btn btn-warning btn-sm fas fa-edit" data-toggle="modal" data-target="#ubah<?php echo e($b->id); ?>">
                                </a href="">
                                <div class="modal fade" id="ubah<?php echo e($b->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                 <div class="modal-content">
                                    <div class="modal-header">
                                    <h4 class="modal-title">Ubah Berita</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                <form action="<?php echo e(url('/berita-admin/update')); ?>/<?php echo e($b->id); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="card-body" style="text-align: left;">
                                        <div class="form-group">
                                            <label>Photo</label>
                                            <input type="file" class="form-control " name="photo" style="height: 45px;">
                                        </div>
                                        <div class="form-group">
                                            <label>Judul</label>
                                            <input class="form-control" name="judul" placeholder="Enter..." value="<?php echo e($b->judul); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Deskripsi</label>
                                            <textarea class="form-control" name="deskripsi" id="editor2" placeholder="Enter..."><?php echo e($b->deskripsi); ?></textarea>
                                     
                                        </div>
                                    </div>
                                </div>
                        <!-- /.card-body -->
                                <div class="modal-footer justify-content-between">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                                </form>
                                </div>
                            </div>
                        </div>
                  </div>
                                <a class="btn btn-sm btn-danger fas fa-trash-alt" href="<?php echo e(url('/berita-admin/delete')); ?>/<?php echo e($b->id); ?>" onclick="return confirm('yakin?');"></a>
                            </td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\manggu\resources\views/layouts/admin/berita-admin.blade.php ENDPATH**/ ?>