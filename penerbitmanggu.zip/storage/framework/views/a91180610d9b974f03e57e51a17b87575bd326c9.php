    

<?php $__env->startSection('title','Data Penjualan dan Royalti'); ?>

<?php $__env->startSection('content'); ?>

<div class="stricky-header stricked-menu main-menu">
    <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
</div>
      <section class="page-header">
            <div class="page-header__bg" style="background-image: url(<?php echo e(asset('assets')); ?>/images/backgrounds/page-header.JPG);"></div>
            <!-- /.page-header__bg -->
            <div class="container">
                <h2>Data Penjualan dan Royalti</h2>
                <ul class="thm-breadcrumb list-unstyled">
                    <li><a href="/">Home</a></li>
                    <li>/</li>
                    <li><span>Data Royalti</span></li>
                </ul><!-- /.thm-breadcrumb list-unstyled -->
            </div><!-- /.container -->
        </section><!-- /.page-header -->
        <section class="about-one">
          <div class="container">
            <div class="tabs-content">
              <div class="tab" id="desc">
                  <div class="product-details-content" style="padding: 4px 4px 8px;">
                      <div class="desc-content-box">
                        <nav class="navbar navbar-light bg-light justify-content-between">
                          <a class="navbar-brand"></a>
                          <form action="<?php echo e(url('data-penjualan-dan-royalti')); ?>" method="GET" class="form-inline">
                            <input type="text" name="search" autocomplete="off" class="form-control mr-sm-2"  placeholder="Cari..." value="<?php echo e(request('search')); ?>">
                            <button class="btn btn-primary" type="submit">Cari</button>
                          </form>

                        </nav>
                          <table class="table table-bordered">
                            <thead class="thead-light">
                              <tr>
                                <th scope="col">No</th>
                                <th scope="col">Judul Buku</th>
                                <th scope="col">Penulis Buku</th>
                                <th scope="col">Harga</th>
                                <th scope="col">Nilai Royalti</th>
                                <th scope="col">Saldo</th>
                                <th scope="col">Terjual</th>
                                <th scope="col">Penambahan</th>
                                <th scope="col">Total Royalti</th>
                                <th scope="col"></th>
                              </tr>
                            </thead>
                            <?php $no=1; ?>
                            <?php $__currentLoopData = $dataroyalti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                              <tr>
                                <th scope="row"><?php echo e($d->id); ?></th>
                                <td><?php echo e($d->judul); ?></td>
                                <td><?php echo e($d->penulis); ?></td>
                                <td>Rp.<?php echo e(number_format($d->harga)); ?></td>
                                <td>Nilai Royalti</td>
                                <td>Saldo</td>
                                <td><?php echo e($d->terjual); ?></td>
                                <td>Rp.<?php echo e($d->harga*$d->terjual); ?></td>
                                <td>Saldo + </td>
                                <!-- <td>Rp.6000</td>
                                <td>Rp.6000</td>
                                <td>Rp.<?php echo e(((($d->harga*$d->terjual)*0.15)-6000)-6000); ?></td> -->
                                <td>
                                  <button type="button" class="btn btn-info" data-toggle="modal" data-target="#exampleModal">Klaim</button>
                                  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <h5 class="modal-title" id="exampleModalLabel">Data Diri Pengajuan Royalti</h5>
                                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                          </button>
                                        </div>
                                        <div class="modal-body">
                                          <div>
                                            <h5><?php echo e($d->judul); ?></h5>
                                            <h5><?php echo e($d->penulis); ?></h5>
                                          </div>
                                          <div class="form-group">
                                            <label>Email</label>
                                            <input class="form-control" name="judul" placeholder="" value="">
                                          </div>
                                          <div class="form-group">
                                            <label>Nama Lengkap</label>
                                            <input class="form-control" name="judul" placeholder="" value="">
                                          </div>
                                          <div class="form-group">
                                            <label>No KTP</label>
                                            <input class="form-control" name="judul" placeholder="" value="">
                                          </div>
                                          <div class="form-group">
                                            <label>No Handphone</label>
                                            <input class="form-control" name="judul" placeholder="" value="">
                                          </div>
                                          <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            <a href="https://wa.me/082214136659" type="button" class="btn btn-primary">Kirim Pengajuan</a>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td> 
                              </tr>
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </table>
                      </div>
                  </div>
              </div>
            </div>
          </div>
          <div class="pagination justify-content-center mt-4">
            <?php echo e($dataroyalti->links()); ?>

          </div>
        </section>    
                       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\penerbitmangguu\resources\views/layouts/data-penjualan-dan-royalti.blade.php ENDPATH**/ ?>