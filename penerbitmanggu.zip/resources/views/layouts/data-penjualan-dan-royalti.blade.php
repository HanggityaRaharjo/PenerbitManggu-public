@extends('layouts.master')    

@section('title','Data Penjualan dan Royalti')

@section('content')

<div class="stricky-header stricked-menu main-menu">
    <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
</div>
      <section class="page-header">
            <div class="page-header__bg" style="background-image: url({{asset('assets')}}/images/backgrounds/page-header.JPG);"></div>
            <!-- /.page-header__bg -->
            <div class="container">
                <h2>Data Penjualan dan Royalti</h2>
                <ul class="thm-breadcrumb list-unstyled">
                    <li><a href="/">Home</a></li>
                    <li>/</li>
                    <li><span>Data Royalti</span></li>
                </ul><!-- /.thm-breadcrumb list-unstyled -->
            </div><!-- /.container -->
        </section><!-- /.page-header -->
        <section class="about-one">
           <div class="container">
            <div class="tabs-content">
              <div class="tab" id="desc">
                  <div class="product-details-content" style="padding: 4px 4px 8px;">
                      <div class="desc-content-box">
                        <nav class="navbar navbar-light bg-light justify-content-between">
                          <a class="navbar-brand"></a>
                          <form action="{{ url('data-penjualan-dan-royalti')}}" method="GET" class="form-inline">
                            <input type="text" name="search" autocomplete="off" class="form-control mr-sm-2"  placeholder="Cari..." value="{{request('search')}}">
                            <button class="btn btn-danger" type="submit">Cari</button>
                          </form>

                        </nav>
                          <table class="table table-bordered">
                            <thead class="thead-light">
                              <tr>
                                <th scope="col">No</th>
                                <th scope="col">Judul Buku</th>
                                <th scope="col">Penulis Buku</th>
                                <!-- Belum Ada Harga -->
                                <th scope="col">Nilai Royalti</th>
                                <th scope="col">Saldo Royalti</th>
                                <th scope="col">Terjual</th>
                                <th scope="col">Penambahan</th>
                                <th scope="col">Saldo Net</th>
                                
                                <th scope="col"></th>
                              </tr>
                            </thead>
                            <?php $no=1; ?>
                            @foreach($dataroyalti as $data)
                            <tbody>
                              <tr>
                                <th scope="col">{{ $no++ }}</th>
                                <td>{{ $data->judul }}</td>
                                <td>{{ $data->penulis }}</td>
                                <td>{{ $data->nilairoyalti }}</td>
                                <td>{{ $data->saldoroyalti }}</td>
                                <td>{{ $data->terjual }}</td>
                                <td>{{ $data->penambahan }}</td>
                                <td>{{ $data->saldonet }}</td>
                                @if($data->saldonet >= 500000)
                                <td><a href="/data-penjualan-dan-royalti/{{ $data->id }}" class="btn btn-primary" disabled>Ambil</a></td>
                                @endif
                                @if($data->saldonet < 500000)
                                <td><a class="btn btn-danger" disabled>Ambil</a></td>
                                @endif
                              
                                <!-- <td><a class="btn btn-success" disabled>Ambil</a></td> -->
                               
                              
                              </tr>
                            </tbody>
                            @endforeach
                          </table>
                      </div>
                  </div>
              </div>
            </div>
          </div>
          <div class="pagination justify-content-center mt-4">
            {{ $dataroyalti->links()}}
          </div>
        </section>    
                       
@endsection